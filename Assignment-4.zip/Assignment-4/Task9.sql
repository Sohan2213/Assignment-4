SELECT id, age, coins_needed, power
FROM Wands
JOIN Wands_Property ON Wands.code = Wands_Property.code

JOIN (
    SELECT age AS alt_age, MIN(coins_needed) AS min_coins_needed, power AS alt_power
    FROM Wands
    JOIN Wands_Property ON Wands.code = Wands_Property.code
    WHERE is_evil = 0
    GROUP BY age, power
) AS ron_preferance ON age = alt_age AND min_coins_needed = coins_needed AND power = alt_power

ORDER BY power DESC, age DESC;