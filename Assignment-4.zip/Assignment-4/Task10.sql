SELECT Hackers.hacker_id, Hackers.name, SUM(challenge_max_score) AS total_score
FROM Hackers
INNER JOIN
(
    SELECT hacker_id, challenge_id, MAX(score) AS challenge_max_score
    FROM Submissions
    GROUP BY hacker_id, challenge_id
) AS maxSubmissions
ON Hackers.hacker_id = maxSubmissions.hacker_id
GROUP BY Hackers.hacker_id, Hackers.name
HAVING total_score <> 0
ORDER BY total_score DESC, Hackers.hacker_id;