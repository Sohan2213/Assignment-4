/*
Enter your query here.
Please append a semicolon ";" at the end of the query and enter your query in a single line to avoid error.
*/
SELECT  
CASE 
    WHEN STUDENTS.MARKS>=70 THEN STUDENTS.NAME
    ELSE NULL
END AS 'Name',
CASE 
    WHEN STUDENTS.MARKS>=90 THEN 10
    WHEN STUDENTS.MARKS>=80 THEN 9
    WHEN STUDENTS.MARKS>=70 THEN 8
    WHEN STUDENTS.MARKS>=60 THEN 7
    WHEN STUDENTS.MARKS>=50 THEN 6
    WHEN STUDENTS.MARKS>=40 THEN 5
    WHEN STUDENTS.MARKS>=30 THEN 4
    WHEN STUDENTS.MARKS>=20 THEN 3
    WHEN STUDENTS.MARKS>=10 THEN 2
    ELSE 1
END AS 'Grades',
STUDENTS.MARKS AS 'Marks'
FROM STUDENTS
ORDER BY 'Grades' DESC, 'Name' ASC;
    